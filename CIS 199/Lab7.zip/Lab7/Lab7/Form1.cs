﻿//Grading ID: C2577
//Lab 7
//Due date: 11/11/2018
//This lab uses the value-returning method in order to calculate how much money one needs to deposit in order to gain a certain value in a certain amount of years with a certain interest rate.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //This event handler when clicked preforms the calculations that result in the present value
        //Pre-Condition: val > 0 && interest > 0 && years > 0
        //Post-Condition: The method will parse the users input, then take the returned value from CalcPresentValue and display it.
        private void calcBtn_Click(object sender, EventArgs e)
        {
            double val; //holds the users future value input
            double interest; //holds the users interest rate
            int years;// holds the number of years
            double total;// holds the present value/the result of the calculations
            if (double.TryParse(valueInpt.Text, out val) && val > 0) //The value must be greater than zero for a person to gain money via interest
            {
                if (double.TryParse(interestInpt.Text, out interest) && interest > 0) //The value must be greater than zero for a person to gain money via interest
                {

                    if (int.TryParse(yearInpt.Text, out years) && years > 0)  //The value must be greater than zero for a person to gain money via interest
                    {
                        total = CalcPresentValue(val, interest, years);
                        calcOutput.Text = $"{total:C}";
                    }
                    else MessageBox.Show("Enter a non negative or 0 integer for year");
                }
                else MessageBox.Show("Enter a non negative or 0 integer  for interest rate");

            }
            else MessageBox.Show("Enter a non negative or 0 integer for Future value");

        }
             //PreCondition: Fval > 0 && Interest Rate > 0 && NumYears > 0
             //PostCondition: Fval is divided by 1 + the interest rate raise by the numyears power. The result is then returned.
            public double CalcPresentValue(double fVal, double interestRate, int numyears)
            {
                double calc; //Holds the calculation result to be returned.
                calc = (fVal) / (Math.Pow(1 + interestRate, numyears));

                return calc;
            }
        
    }
}
