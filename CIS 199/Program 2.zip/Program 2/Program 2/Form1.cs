﻿//Grading ID: C2577
// Program 2
// Oct 18th
// Section 75
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // This is the event handler that will give the user the date and time of their registration
        private void submitBtn_Click(object sender, EventArgs e)
        {
            char ch; //holds the character that is assumed the person will enter
            string time; // this will hold the time to be outputted 
            string day; // This will hold the day depending on the users class and last name
           const string TIME1 = "8:30 AM"; //Constant for the first/earliest time slot
           const string TIME2 = "10:00 AM"; // Constant for the 2nd time slot
           const string TiME3 = "11:30 AM"; // Constant for the 3rd time slot
           const  string TIME4 = "2:00 PM"; // Constant for the 4th time slot
           const string TIME5 = "4:00 PM"; // Constant for the 5th time slot
           const string DAY1 = "November 2nd"; // Constant for the first date
           const string DAY2 = "November 5th"; // Constant for the 2nd date
           const string DAY3 = "November 6th"; // Constant for the 3rd date
           const string DAY4 = "November 7th"; // Constant for the 4th date
           const string DAY5 = "November 8th"; // Constant for the 5th date
           const string DAY6 = "November 9th"; // Constant for the last date

            if (char.TryParse(nameInpt.Text, out ch)) // Parsing the users input into a string that will be stored in variable ch
            {
                if (char.IsLetter(ch)) //This determines if the entered text is a letter, if it is it will go on with the code
                {
                    ch = char.ToUpper(ch); // Converts the letter into uppercase

                    if (seniorBtn.Checked || juniorBtn.Checked) //Checks what radiobutton was checked
                    {
                        if (ch <= 'D') //This section from line 49 to 57 is using if else to determine the timeslot the user falls in
                           time = TIME5;
                        else if (ch <= 'I')
                            time = TIME1;
                        else if (ch <= 'O')
                            time = TIME2;
                        else if (ch <= 'S')
                            time = TiME3;
                        else time = TIME4;

                        if (seniorBtn.Checked) 
                            day = DAY1;
                            else day = DAY2;
                        dayOutput.Text = $"{day} at {time}";

                    }
                    else
                    {
                        if (ch <= 'B') // Like line 49 to 57, line 67 to 85 is all used to determine the timeslot of the user
                            time = TIME4;
                        else if (ch <= 'D')
                            time = TIME5;
                        else if (ch <= 'F')
                            time = TIME1;
                        else if (ch <= 'I')
                            time = TIME2;
                        else if (ch <= 'L')
                            time = TiME3;
                        else if (ch <= 'O')
                            time = TIME4;
                        else if (ch <= 'Q')
                            time = TIME5;
                        else if (ch <= 'S')
                            time = TIME1;
                        else if (ch <= 'V')
                            time = TIME2;
                        else time = TiME3;

                        if (ch >= 'E' && ch <= 'Q')
                        {
                            if (sophmoreBtn.Checked)
                                day = DAY3;
                            else day = DAY5;

                        }
                        else if (sophmoreBtn.Checked)
                            day = DAY4;
                        else day = DAY6;

                        dayOutput.Text = $"{day} at {time}";


                    }
                }
            }
        }
    }
}
