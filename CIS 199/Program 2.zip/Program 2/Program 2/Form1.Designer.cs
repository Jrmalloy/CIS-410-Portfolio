﻿namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nameInpt = new System.Windows.Forms.TextBox();
            this.freshmanBtn = new System.Windows.Forms.RadioButton();
            this.sophmoreBtn = new System.Windows.Forms.RadioButton();
            this.juniorBtn = new System.Windows.Forms.RadioButton();
            this.seniorBtn = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.submitBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dayOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Last Name";
            // 
            // nameInpt
            // 
            this.nameInpt.Location = new System.Drawing.Point(104, 140);
            this.nameInpt.Name = "nameInpt";
            this.nameInpt.Size = new System.Drawing.Size(100, 20);
            this.nameInpt.TabIndex = 1;
            // 
            // freshmanBtn
            // 
            this.freshmanBtn.AutoSize = true;
            this.freshmanBtn.Location = new System.Drawing.Point(18, 37);
            this.freshmanBtn.Name = "freshmanBtn";
            this.freshmanBtn.Size = new System.Drawing.Size(71, 17);
            this.freshmanBtn.TabIndex = 2;
            this.freshmanBtn.TabStop = true;
            this.freshmanBtn.Text = "Freshman";
            this.freshmanBtn.UseVisualStyleBackColor = true;
            // 
            // sophmoreBtn
            // 
            this.sophmoreBtn.AutoSize = true;
            this.sophmoreBtn.Location = new System.Drawing.Point(18, 60);
            this.sophmoreBtn.Name = "sophmoreBtn";
            this.sophmoreBtn.Size = new System.Drawing.Size(73, 17);
            this.sophmoreBtn.TabIndex = 3;
            this.sophmoreBtn.TabStop = true;
            this.sophmoreBtn.Text = "Sophmore";
            this.sophmoreBtn.UseVisualStyleBackColor = true;
            // 
            // juniorBtn
            // 
            this.juniorBtn.AutoSize = true;
            this.juniorBtn.Location = new System.Drawing.Point(18, 83);
            this.juniorBtn.Name = "juniorBtn";
            this.juniorBtn.Size = new System.Drawing.Size(53, 17);
            this.juniorBtn.TabIndex = 4;
            this.juniorBtn.TabStop = true;
            this.juniorBtn.Text = "Junior";
            this.juniorBtn.UseVisualStyleBackColor = true;
            // 
            // seniorBtn
            // 
            this.seniorBtn.AutoSize = true;
            this.seniorBtn.Location = new System.Drawing.Point(18, 106);
            this.seniorBtn.Name = "seniorBtn";
            this.seniorBtn.Size = new System.Drawing.Size(55, 17);
            this.seniorBtn.TabIndex = 5;
            this.seniorBtn.TabStop = true;
            this.seniorBtn.Text = "Senior";
            this.seniorBtn.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Select class standing classification";
            // 
            // submitBtn
            // 
            this.submitBtn.Location = new System.Drawing.Point(18, 171);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(75, 23);
            this.submitBtn.TabIndex = 8;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Registration Date";
            // 
            // dayOutput
            // 
            this.dayOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayOutput.Location = new System.Drawing.Point(104, 209);
            this.dayOutput.Name = "dayOutput";
            this.dayOutput.Size = new System.Drawing.Size(152, 23);
            this.dayOutput.TabIndex = 10;
            this.dayOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AcceptButton = this.submitBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 276);
            this.Controls.Add(this.dayOutput);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.submitBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.seniorBtn);
            this.Controls.Add(this.juniorBtn);
            this.Controls.Add(this.sophmoreBtn);
            this.Controls.Add(this.freshmanBtn);
            this.Controls.Add(this.nameInpt);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameInpt;
        private System.Windows.Forms.RadioButton freshmanBtn;
        private System.Windows.Forms.RadioButton sophmoreBtn;
        private System.Windows.Forms.RadioButton juniorBtn;
        private System.Windows.Forms.RadioButton seniorBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label dayOutput;
    }
}

