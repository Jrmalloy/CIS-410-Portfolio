﻿// Grading ID: C2577
// CIS 199-75
// Lab 5
// Due: 10/21/2018
// This code uses loops to create patterns using * and spaces.
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10; //This variable represents what the limit of rows the program should run

            WriteLine("Pattern A"); //Simple WriteLine to label each pattern
            WriteLine("");
            for (int row = 1; row <= MAX_ROWS; row++) // For loop declaring the variable int and setting the condition that it cannot be greater than Max_Rows
            {
                for (int star = 1; star <= row; star++) // Inner For Loop that declares star and the condition for it.
                Write("*");
                WriteLine();
            }
            WriteLine("Pattern B");
            WriteLine("");
            for (int row = MAX_ROWS ; row >= 1 ; row--) // Changed row to = MAX_ROWS and changed the condition for row to be >=1 so that the pattern goes in reverse
            {
                for (int star = 1; star <= row; star++)
                Write("*");
                WriteLine();
            }
            WriteLine("Pattern C");
            WriteLine("");
            for (int row = MAX_ROWS; row >= 1; row--)
            {
                for (int space = 1; space <= MAX_ROWS-row; space++) //This loop is used to determine the amount of spaces needed in pattern C, the space is always the left over amount of MAX_ROW-row
                    Write(" ");
                for (int star = 1; star <= row; star++)
                Write("*");
                WriteLine();
            }
            WriteLine("Pattern D");
            WriteLine("");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)
                    Write(" ");
                for (int star = 1; star <= row; star++)
                    Write("*");
                WriteLine();
            }
        }
    }
}
