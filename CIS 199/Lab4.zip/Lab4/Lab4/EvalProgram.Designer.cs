﻿namespace Lab4
{
    partial class EvalProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.gpaInput = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.scoreInput = new System.Windows.Forms.TextBox();
            this.evalBtn = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numAccepted = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numRejected = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Grade Point Average";
            // 
            // gpaInput
            // 
            this.gpaInput.Location = new System.Drawing.Point(152, 23);
            this.gpaInput.Name = "gpaInput";
            this.gpaInput.Size = new System.Drawing.Size(100, 20);
            this.gpaInput.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter Admission Test Score";
            // 
            // scoreInput
            // 
            this.scoreInput.Location = new System.Drawing.Point(152, 76);
            this.scoreInput.Name = "scoreInput";
            this.scoreInput.Size = new System.Drawing.Size(100, 20);
            this.scoreInput.TabIndex = 1;
            // 
            // evalBtn
            // 
            this.evalBtn.Location = new System.Drawing.Point(71, 164);
            this.evalBtn.Name = "evalBtn";
            this.evalBtn.Size = new System.Drawing.Size(75, 23);
            this.evalBtn.TabIndex = 2;
            this.evalBtn.Text = "Evaluate";
            this.evalBtn.UseVisualStyleBackColor = true;
            this.evalBtn.Click += new System.EventHandler(this.evalBtn_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLabel.Location = new System.Drawing.Point(152, 121);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(100, 23);
            this.outputLabel.TabIndex = 5;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Number of Applications Accepted";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(162, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Number of Applications Rejected";
            // 
            // numAccepted
            // 
            this.numAccepted.AutoSize = true;
            this.numAccepted.Location = new System.Drawing.Point(180, 214);
            this.numAccepted.Name = "numAccepted";
            this.numAccepted.Size = new System.Drawing.Size(13, 13);
            this.numAccepted.TabIndex = 8;
            this.numAccepted.Text = "0";
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(184, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 0);
            this.label6.TabIndex = 9;
            // 
            // numRejected
            // 
            this.numRejected.AutoSize = true;
            this.numRejected.Location = new System.Drawing.Point(180, 253);
            this.numRejected.Name = "numRejected";
            this.numRejected.Size = new System.Drawing.Size(13, 13);
            this.numRejected.TabIndex = 10;
            this.numRejected.Text = "0";
            // 
            // clearBtn
            // 
            this.clearBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearBtn.Location = new System.Drawing.Point(177, 164);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 3;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // EvalProgram
            // 
            this.AcceptButton = this.evalBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearBtn;
            this.ClientSize = new System.Drawing.Size(330, 294);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.numRejected);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numAccepted);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.evalBtn);
            this.Controls.Add(this.scoreInput);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gpaInput);
            this.Controls.Add(this.label1);
            this.Name = "EvalProgram";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox gpaInput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox scoreInput;
        private System.Windows.Forms.Button evalBtn;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label numAccepted;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label numRejected;
        private System.Windows.Forms.Button clearBtn;
    }
}

