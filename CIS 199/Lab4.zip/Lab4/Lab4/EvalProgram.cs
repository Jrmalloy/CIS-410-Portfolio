﻿//Grading ID: C5
// Lab 4
// CIS-199-75
// This lab's purpose is to evaluate whether or not a person should be accepted or rejected based off of their test scores and gpa while keeping a running tally on how many where accepted and rejected
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class EvalProgram : Form
    {
        private int acceptedOutput = 0; //This is the variable used for the counter that holds the amount of applications accepted
        private int rejectedOutput = 0; // This is the variable for the counter for the amount of applications rejected

        public EvalProgram()
        {
            InitializeComponent();
        }

        // This button when clicked executes the code that evalutes whether the person is accepted or rejected & updates the counter to reflect that
        private void evalBtn_Click(object sender, EventArgs e)
        {
            const double MIN_GPA = 3.0; //This holds the magical number that is the min gpa requirement for one of the acceptance conditions
            const int MIN_TESTSCORE1 = 60; // This constant represents the test score that goes with the higher gpa requirement
            const int MIN_TESTSCORE2 = 80; // This constant represents the min test score for the lower gpa requirements
            double gpaOutput; //This variable is going to be used to hold the users inputed gpa
            int scoreOutput; // This variable is going to be used to hold the users inputed gpa

            if (double.TryParse(gpaInput.Text, out gpaOutput) && gpaOutput >= 0) 
            {
                if (int.TryParse(scoreInput.Text, out scoreOutput) && scoreOutput >= 0)
                {
                    if ((gpaOutput >= MIN_GPA && scoreOutput >= MIN_TESTSCORE1) || gpaOutput < MIN_GPA && scoreOutput >= MIN_TESTSCORE2) // This is the if statement created to test the users input against the two scenerios allowing an acceptance
                    {
                        outputLabel.Text = "Accept";
                        outputLabel.BackColor = Color.LawnGreen; // I added this portion for asthetic purposes, a green color is usually indicates good
                        acceptedOutput = ++acceptedOutput; //Adds +1 to the accepted counter
                    }
                    else
                    {
                        outputLabel.Text = "Reject";
                        outputLabel.BackColor = Color.Red; // This code will change the output box to be red, mainly for astehtic purposes
                        rejectedOutput = ++rejectedOutput; // Adds +1 to the rejected counter
                    }
                    numAccepted.Text = $"{acceptedOutput}";
                    numRejected.Text = $"{rejectedOutput}";
                }
                else
                {
                    MessageBox.Show("Enter a valid non-negative number for TestScore!");
                }

            }
            else
            {
                MessageBox.Show("Enter a valid non-negative number for GPA!");
            }
          
        }
        // This is a clear button made to allow the user to easily clear the gpa and score text boxes and test more.
        private void clearBtn_Click(object sender, EventArgs e)
        {
            gpaInput.Text = ""; // Clears gpa text box
            scoreInput.Text = ""; // Clears the test score text box
            outputLabel.Text = ""; // Clears the output text
            outputLabel.BackColor = Color.Transparent; // This resets the output labels color back to transparent from either red or green

            gpaInput.Focus(); // This puts the focus back on the first text box (the gpa input) to allow the user to easily enter in a new set of inputs
        }
    }
}
