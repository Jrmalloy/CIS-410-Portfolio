﻿// Grading ID: C2577
// CIS 199-75
// Program 1
// Due: 9/25/2018
// This code's purpose is to calculate the amount of gallons of paint one needs to buy given certain measurements
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace Progam1
{
    class Program
    {
        static void Main(string[] args)
        {
            const int DOORSPACE = 20; //Variable that represents the space that a door takes up
            const int WINDOWSPACE = 15; //Variable that represents the space that a window takes up
            const double SQ_FT_PER_CAN = 385; //Variable that represents the amount of paint 
            double totalWallLength; //Variable that represents the total wall length
            double wallHeight; // Variable that represents the height of the wall
            int numDoors; //This variable represents the number of doors
            int numWindows; // This variable represents the number of windows
            int paintCoat; // Variable for number of coats of paint
            double minGallons; //Variable to hold the calculations
            int gallonsToBuy; // Variable that holds the calculations for how much gallons to buy

            WriteLine("Welcome to the Handy-Dandy Paint Estimator");
            WriteLine("");
            Write("Enter the total length of all walls (in feet): ");
            totalWallLength = double.Parse(ReadLine());
            Write("Enter the height of the walls (in feet): ");
            wallHeight = double.Parse(ReadLine());
            Write("Enter the number of doors (non-neg int): ");
            numDoors = int.Parse(ReadLine());
            Write("Enter the number windows (non-neg int): ");
            numWindows = int.Parse(ReadLine());
            Write("Enter the number of coats of paint (non-neg int): ");
            paintCoat = int.Parse(ReadLine());

            minGallons = (totalWallLength * wallHeight - (numDoors * DOORSPACE) - (numWindows * WINDOWSPACE)) * paintCoat / SQ_FT_PER_CAN; // Calculation for the minimum amount of gallons needed
            gallonsToBuy = (int)Math.Ceiling(minGallons); // This causes the value given in minGallons to be rounded up as one cannot buy a decimal point of gallons of paint

            WriteLine("");
            WriteLine($"You need a minimum of {minGallons:F1} gallons of paint");
            WriteLine($"You'll need to buy {gallonsToBuy:F0} gallons, though");





        }
    }
}
