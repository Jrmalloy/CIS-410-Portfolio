﻿// Grading ID: C2577
// CIS 199-75
// Lab 6
// Due: 10/28/2018
// This lab uses parallel arrays and range matching to determine the users grade
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Event handler that executes the code below it when the user clicks the button
        private void evalBtn_Click(object sender, EventArgs e)
        {
            int numOfWords; //This int variable is declared to hold the value of the number of words the user typed
            int[] numRanges = new int[] { 0, 16, 31, 51, 76 }; //Array for the min values for each letter grade
            char[] gradeLetter = new char[] { 'F', 'D', 'C', 'B', 'A' }; //Array for the letter grades
            char grade = 'F'; // Character that holds the first letter grade in the array
            if (int.TryParse(numWords.Text, out numOfWords) && numOfWords >= 0) //Try parse to prevent the user from crashing the program
            {
                for (int index = numRanges.Length - 1; index >= 0; index--) 
                {
                    if (numOfWords >= numRanges[index])
                    {
                        grade = gradeLetter[index];
                        break; //Breaks the loop so that the output box can be updated
                    }
                }

                outputLbl.Text = $"You got a(n) {grade}";
            }
            else MessageBox.Show("Enter a valid non-negative whole number");
        }
    }
}
