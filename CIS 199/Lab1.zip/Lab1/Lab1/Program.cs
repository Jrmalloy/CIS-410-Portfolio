﻿// Grading ID: C2577
// CIS 199-75
// Lab 1
// Due: 9/2/2018
// This code uses WriteLine in order to create a sort of introduction of myself.
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Grading ID:     C2577");
            WriteLine("Hobbies:        Playing video games and listening to music");
            WriteLine("Favorite Book:  Mary Shelley's Frankenstein");
            WriteLine("Favorite Movie: Spider-man: Homecoming");
        }
    }
}
