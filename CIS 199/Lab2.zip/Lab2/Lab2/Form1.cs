﻿// Grading ID: C2577
// CIS 199-75
// Lab 2
// Due: 9/16/2018
// This is a program built to calculate the tip when given a meal price
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // This is the calc button
        private void calcBtn_Click(object sender, EventArgs e)
        {
            const double LOWTIP = 0.15; //This is the constant variable used for low tipping amounts
            const double MIDTIP = 0.18; // This is the constant variable used for middle tipping amounts
            const double TOPTIP = 0.2; // This is the constant variable used for top tipping amounts
            double mealPrice; // This variable represents the meal price that the user enters
            double lowTipAmt; // This variable holds the calculation for a low tip amount
            double midTipAmt; // This variable holds the calculation for a middle tip amount
            double topTipAmt; // This variable holds the calculation for a top tip amount

            mealPrice = double.Parse(mealPriceInputTxt.Text);
            lowTipAmt = mealPrice * LOWTIP;
            midTipAmt = mealPrice * MIDTIP;
            topTipAmt = mealPrice * TOPTIP;

            outputLow.Text = $"{lowTipAmt:C}";
            outputMid.Text = $"{midTipAmt:C}";
            outputHigh.Text = $"{topTipAmt:C}";

        }
    }
}
