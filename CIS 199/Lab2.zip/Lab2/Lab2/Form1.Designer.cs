﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.mealPriceInputTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.outputLow = new System.Windows.Forms.Label();
            this.outputMid = new System.Windows.Forms.Label();
            this.outputHigh = new System.Windows.Forms.Label();
            this.calcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter price of meal:";
            // 
            // mealPriceInputTxt
            // 
            this.mealPriceInputTxt.Location = new System.Drawing.Point(113, 6);
            this.mealPriceInputTxt.Name = "mealPriceInputTxt";
            this.mealPriceInputTxt.Size = new System.Drawing.Size(100, 20);
            this.mealPriceInputTxt.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "15%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "18%";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "20%";
            // 
            // outputLow
            // 
            this.outputLow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLow.Location = new System.Drawing.Point(113, 39);
            this.outputLow.Name = "outputLow";
            this.outputLow.Size = new System.Drawing.Size(100, 23);
            this.outputLow.TabIndex = 5;
            // 
            // outputMid
            // 
            this.outputMid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputMid.Location = new System.Drawing.Point(113, 69);
            this.outputMid.Name = "outputMid";
            this.outputMid.Size = new System.Drawing.Size(100, 23);
            this.outputMid.TabIndex = 6;
            // 
            // outputHigh
            // 
            this.outputHigh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputHigh.Location = new System.Drawing.Point(113, 98);
            this.outputHigh.Name = "outputHigh";
            this.outputHigh.Size = new System.Drawing.Size(100, 23);
            this.outputHigh.TabIndex = 7;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(77, 141);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(90, 23);
            this.calcBtn.TabIndex = 8;
            this.calcBtn.Text = "Calculate Tip";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.outputHigh);
            this.Controls.Add(this.outputMid);
            this.Controls.Add(this.outputLow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mealPriceInputTxt);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox mealPriceInputTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label outputLow;
        private System.Windows.Forms.Label outputMid;
        private System.Windows.Forms.Label outputHigh;
        private System.Windows.Forms.Button calcBtn;
    }
}

